</div>
</div>

<footer class="jumbotron text-center mb-0 jumbotron-fluid pt-5 pb-4 ">
    <div class="container ">
        <div class="row">
            <p class="col-12 col-sm-4 border border-dark align-self-center"><a href="#page">Haut de la page</a></p>
            <p class="col-12 col-sm-4 border border-dark align-self-center">Copyright 2022</p>
            <p class="col-12 col-sm-4 border border-dark align-self-center">420-W24-SF</p>
            <p class="col-12 col-sm-4 border border-dark align-self-center">Travail Pratique 2</p>
            <p class="col-12 col-sm-8 border border-dark align-self-center">Dominique Lebrun, Tien Binh Nguyen et Michel Couture</p>
        </div>
    </div>
</footer>
</div>



<?php
    
    // //À supprimer
    // // $panier = unserialize($_SESSION['cart']);
    // // var_dump($panier->getItems()[0]['item']);


    // //REQUEST
    // echo 'REQUEST :<br>';
    // var_dump($_REQUEST);

    // //POST
    // echo '<br><br>POST :<br>';
    // var_dump($_POST);

    // //SESSION
    // echo '<br><br>SESSION :<br>';
    // var_dump($_SESSION);

    //  //SESSION unserialize panier
    //  echo '<br><br>SESSION UNSERIALIZE: CART<br>';
    //  if (isset($_SESSION['cart'])) {
    //      var_dump(unserialize($_SESSION['cart']));
    //  }
    //  else {
    //      echo "La variable est vide.";
    //  }

    // //SESSION unserialize login
    // echo '<br><br>SESSION UNSERIALIZE: LOGIN<br>';
    // if (isset($_SESSION['login'])) {
    //     var_dump(unserialize($_SESSION['login']));
    // }
    // else {
    //     echo "La variable est vide.";
    // }

    // //COOKIE
    // echo '<br><br>COOKIE :<br>';
    // var_dump($_COOKIE);

    // //SERVER
    // echo '<br><br>SERVER :<br>';
    // var_dump($_SERVER);
    
?>


<!-- Jquery, Popper,Bootstrap 4.6 -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</body>

</html>